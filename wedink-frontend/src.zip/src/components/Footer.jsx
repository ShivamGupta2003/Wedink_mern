export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="social-icons">
          <a href="#"><i className="fab fa-facebook"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
          <a href="#"><i className="fab fa-linkedin"></i></a>
        </div>
        <div className="copyright">© WedInk Private Limited</div>
        <div className="terms">
          <span>Privacy</span>
          <span className="heart">❤</span>
          <span>Shivam</span>
          <span className="heart">❤</span>
          <span>Terms</span>
        </div>
      </div>
    </footer>
  )
}
