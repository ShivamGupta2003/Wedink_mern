import Navbar from './Navbar'
import Footer from './Footer'
import FlashMessage from './FlashMessage'

export default function Layout({ children }) {
  return (
    <>
      <Navbar />
      <div className="main-content">
        <div className="container">
          <FlashMessage />
        </div>
        {children}
      </div>
      <Footer />
    </>
  )
}
