import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useFlash } from '../context/FlashContext'
import api from '../services/api'

export default function Navbar() {
  const { curruser, logout } = useAuth()
  const { showSuccess, showError } = useFlash()
  const navigate = useNavigate()
  const [search, setSearch] = useState('')

  const handleLogout = async () => {
    try {
      await api.get('/auth/logout')
      logout()
      showSuccess('You are LoggedOut Successfully !!')
      navigate('/')
    } catch {
      showError('Logout failed')
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    navigate(`/listings?shopName=${encodeURIComponent(search)}`)
  }

  return (
    <>
      {/* Offcanvas for mobile */}
      <div
        className="offcanvas offcanvas-start"
        tabIndex="-1"
        id="offcanvasNavbar"
        aria-labelledby="offcanvasNavbarLabel"
      >
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
            <i className="fas fa-rings me-2"></i>WedInk
          </h5>
          <button
            type="button"
            className="btn-close btn-close-white"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link active" to="/listings" data-bs-dismiss="offcanvas">
                <i className="fas fa-home me-2"></i>Home
              </Link>
            </li>
            {!curruser && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/login" data-bs-dismiss="offcanvas">
                    <i className="fas fa-sign-in-alt me-2"></i>Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/signup" data-bs-dismiss="offcanvas">
                    <i className="fas fa-user-plus me-2"></i>Sign Up
                  </Link>
                </li>
              </>
            )}
            {curruser && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/users/bookings" data-bs-dismiss="offcanvas">
                    <i className="fas fa-calendar-check me-2"></i>My Orders
                  </Link>
                </li>
                <li className="nav-item">
                  <button className="nav-link btn btn-link" onClick={handleLogout}>
                    <i className="fas fa-sign-out-alt me-2"></i>Logout
                  </button>
                </li>
              </>
            )}
          </ul>
          <form onSubmit={handleSearch} className="mt-4">
            <div className="input-group">
              <input
                className="form-control"
                type="search"
                placeholder="Search shop..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <button
                type="submit"
                style={{
                  padding: '4px 30px',
                  fontSize: '12px',
                  backgroundColor: '#007bff',
                  color: 'white',
                  borderRadius: '2px',
                  border: 'none',
                  cursor: 'pointer',
                }}
              >
                <i className="fas fa-search" style={{ fontSize: '12px' }}></i>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Main Navbar */}
      <nav className="navbar navbar-expand-lg fixed-top">
        <div className="container">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar"
          >
            <i className="fas fa-bars text-white"></i>
          </button>

          <Link className="navbar-brand" to="/">
            <i className="fa-regular fa-compass mass"></i>
          </Link>

          <div className="collapse navbar-collapse">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" to="/">WedInk</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/listings">Home</Link>
              </li>
              {!curruser && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/login">Login</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link" to="/signup">Sign Up</Link>
                  </li>
                </>
              )}
              {curruser && (
                <>
                  <li className="nav-item">
                    <Link className="nav-link" to="/users/bookings">My Orders</Link>
                  </li>
                  <li className="nav-item">
                    <button
                      className="nav-link btn btn-link p-0"
                      style={{ textDecoration: 'none' }}
                      onClick={handleLogout}
                    >
                      Logout
                    </button>
                  </li>
                </>
              )}
            </ul>

            <form onSubmit={handleSearch} className="d-flex">
              <div className="input-group">
                <input
                  className="form-control"
                  type="search"
                  placeholder="Search shop..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                <button
                  type="submit"
                  style={{
                    padding: '4px 30px',
                    fontSize: '12px',
                    backgroundColor: '#007bff',
                    color: 'white',
                    borderRadius: '2px',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                >
                  <i className="fas fa-search" style={{ fontSize: '12px' }}></i>
                </button>
              </div>
            </form>
          </div>
        </div>
      </nav>
    </>
  )
}
