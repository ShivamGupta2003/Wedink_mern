export default function CardEdit() {
  return <div className='container mt-5'><h2>CardEdit - Coming Soon</h2></div>
}
