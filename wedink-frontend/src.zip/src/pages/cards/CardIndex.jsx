export default function CardIndex() {
  return <div className='container mt-5'><h2>CardIndex - Coming Soon</h2></div>
}
