export default function CardNew() {
  return <div className='container mt-5'><h2>CardNew - Coming Soon</h2></div>
}
