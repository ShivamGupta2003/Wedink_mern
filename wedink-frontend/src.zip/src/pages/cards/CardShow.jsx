export default function CardShow() {
  return <div className='container mt-5'><h2>CardShow - Coming Soon</h2></div>
}
