export default function ErrorPage() {
  return <div className='container mt-5'><h2>ErrorPage - Coming Soon</h2></div>
}
