import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

export default function FrontPage() {
  const navigate = useNavigate()
  const textRef = useRef(null)
  const timerRef = useRef(null)

  useEffect(() => {
    const text = 'WedInk'
    const el = textRef.current
    if (!el) return
    let index = 0
    el.innerHTML = ''
    function showLetter() {
      if (index < text.length) {
        el.innerHTML += text[index]
        index++
        timerRef.current = setTimeout(showLetter, 400)
      } else {
        timerRef.current = setTimeout(() => { el.innerHTML = ''; index = 0; showLetter() }, 6000)
      }
    }
    showLetter()
    return () => clearTimeout(timerRef.current)
  }, [])

  return (
    <>
      <style>{`
        .video-section { position:relative; width:100%; height:100vh; overflow:hidden; }
        .video-container { position:absolute; top:0; left:0; width:100%; height:100%; overflow:hidden; background-color:rgba(0,0,0,0.6) !important; }
        .video-container video { position:absolute; top:50%; left:50%; min-width:100%; min-height:100%; width:auto; height:auto; transform:translate(-50%,-50%); object-fit:cover; z-index:-1; }
        .front-content { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); text-align:center; color:white; z-index:1; width:90%; }
        .front-content h1 { font-size:5rem !important; }
        .front-content p { font-size:1.2rem; }
        @media(max-width:912px) { .front-content h1{font-size:4rem!important;margin-bottom:.6rem!important;} .front-content p{font-size:0.7rem!important;} }
        @media(min-width:320px) and (max-width:941px) { .front-content h1{font-size:4.5rem;} .front-content p{font-size:0.8rem;} }
        .roundess { border-radius:90%!important; }
        @keyframes fadeBounce { 0%{opacity:0;transform:translateY(-30px);} 50%{opacity:.5;transform:translateY(10px);} 100%{opacity:1;transform:translateY(0);} }
        .animated-text { color:skyblue!important; text-decoration:underline!important; font-size:5rem!important; animation:fadeBounce 1.5s ease-in-out forwards; }
        @media(max-width:768px) { .animated-text{font-size:3.5rem!important;} }
        @keyframes popAnimation { 0%{transform:scale(1);} 50%{transform:scale(1.1);} 100%{transform:scale(1);} }
        .pop-button { transition:transform .2s ease,box-shadow .2s ease; animation:popAnimation 1.5s infinite ease-in-out; }
        .pop-button:hover { transform:scale(1.15); box-shadow:0px 8px 20px rgba(0,0,0,.3); }
        .pop-button:active { transform:scale(.9); }
      `}</style>
      <Navbar />
      <section className="video-section">
        <div className="video-container">
          <video autoPlay loop muted playsInline>
            <source src="/images/8551791-uhd_3840_2160_25fps.mp4" type="video/mp4" />
          </video>
        </div>
        <div className="front-content">
          <h1 ref={textRef} className="animated-text">WedInk</h1>
          <p>Ultimate destination for creating custom celebration cards online! Whether it's a wedding, birthday, or any special occasion, we help you design unique and personalized cards to suit your event perfectly</p>
          <button className="btn btn-primary btn-lg roundess pop-button mt-3" onClick={() => navigate('/listings')}>
            Explore
          </button>
        </div>
      </section>
      <div className="foor"><Footer /></div>
    </>
  )
}