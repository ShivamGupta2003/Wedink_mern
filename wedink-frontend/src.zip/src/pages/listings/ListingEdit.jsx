export default function ListingEdit() {
  return <div className='container mt-5'><h2>ListingEdit - Coming Soon</h2></div>
}
