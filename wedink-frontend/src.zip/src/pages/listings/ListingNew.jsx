export default function ListingNew() {
  return <div className='container mt-5'><h2>ListingNew - Coming Soon</h2></div>
}
