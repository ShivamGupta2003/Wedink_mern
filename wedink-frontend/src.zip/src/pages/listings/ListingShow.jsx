export default function ListingShow() {
  return <div className='container mt-5'><h2>ListingShow - Coming Soon</h2></div>
}
