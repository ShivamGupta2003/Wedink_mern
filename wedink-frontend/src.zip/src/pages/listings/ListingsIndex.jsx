export default function ListingsIndex() {
  return <div className='container mt-5'><h2>ListingsIndex - Coming Soon</h2></div>
}
