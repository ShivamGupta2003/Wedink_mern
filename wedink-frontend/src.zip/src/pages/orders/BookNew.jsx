export default function BookNew() {
  return <div className='container mt-5'><h2>BookNew - Coming Soon</h2></div>
}
