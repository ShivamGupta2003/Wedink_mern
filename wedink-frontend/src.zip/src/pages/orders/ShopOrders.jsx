export default function ShopOrders() {
  return <div className='container mt-5'><h2>ShopOrders - Coming Soon</h2></div>
}
