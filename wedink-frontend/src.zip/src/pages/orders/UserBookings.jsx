export default function UserBookings() {
  return <div className='container mt-5'><h2>UserBookings - Coming Soon</h2></div>
}
