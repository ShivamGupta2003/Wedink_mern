import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import Layout from '../../components/Layout'
import { useAuth } from '../../context/AuthContext'
import { useFlash } from '../../context/FlashContext'
import api from '../../services/api'

export default function Login() {
  const { login } = useAuth()
  const { showSuccess, showError } = useFlash()
  const navigate = useNavigate()
  const location = useLocation()

  const [form, setForm] = useState({ username: '', password: '' })
  const [validated, setValidated] = useState(false)
  const [loading, setLoading] = useState(false)

  // After login, go back to where they were (or /listings)
  const from = location.state?.from?.pathname || '/listings'

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleFocus = (e) => {
    const label = e.target.closest('.mb-3')?.querySelector('.form-label')
    if (label) label.style.color = '#28a745'
  }

  const handleBlur = (e) => {
    if (!e.target.value) {
      const label = e.target.closest('.mb-3')?.querySelector('.form-label')
      if (label) label.style.color = ''
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setValidated(true)

    if (!e.target.checkValidity()) return

    setLoading(true)
    try {
      const res = await api.post('/auth/login', form)
      login(res.data.user)
      showSuccess('Welcome To WedInk You are LoggedIn')
      navigate(from, { replace: true })
    } catch (err) {
      showError(err.response?.data?.message || 'Invalid username or password')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout>
      <div className="container min-vh-100 d-flex align-items-center">
        <div className="row justify-content-center w-100 move-up">
          <div className="col-lg-5 col-md-7 col-sm-12">
            <div className="card shadow-lg p-4 animate__animated animate__fadeInUp">
              <div className="text-center mb-4 animate__animated animate__fadeInDown">
                <span className="fs-1">💌</span>
                <h2 className="text-success fw-bold">Welcome Back</h2>
                <p className="text-muted">Login to create beautiful Celebration Cards</p>
              </div>

              <form
                onSubmit={handleSubmit}
                className={`needs-validation ${validated ? 'was-validated' : ''}`}
                noValidate
              >
                <div className="mb-3 animate__animated animate__fadeInLeft" style={{ animationDelay: '0.2s' }}>
                  <label className="form-label fw-bold">Username</label>
                  <input
                    type="text"
                    name="username"
                    className="form-control border-success"
                    placeholder="Enter your username"
                    value={form.username}
                    onChange={handleChange}
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    required
                  />
                  <div className="invalid-feedback">Please enter your username</div>
                </div>

                <div className="mb-3 animate__animated animate__fadeInRight" style={{ animationDelay: '0.3s' }}>
                  <label className="form-label fw-bold">Password</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control border-success"
                    placeholder="Enter your password"
                    value={form.password}
                    onChange={handleChange}
                    onFocus={handleFocus}
                    onBlur={handleBlur}
                    required
                  />
                  <div className="invalid-feedback">Please enter your password</div>
                </div>

                <div className="text-center animate__animated animate__fadeInUp" style={{ animationDelay: '0.4s' }}>
                  <button
                    type="submit"
                    className="btn btn-success btn-lg w-100 shadow"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        Logging in...
                      </>
                    ) : 'Log In'}
                  </button>
                </div>
              </form>

              <div className="text-center mt-3 animate__animated animate__fadeIn" style={{ animationDelay: '0.5s' }}>
                <Link to="/signup" className="text-success text-decoration-none">
                  New to WedInk? Create Account
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}
